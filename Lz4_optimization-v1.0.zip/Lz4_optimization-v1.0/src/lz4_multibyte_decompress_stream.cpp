/*
 * (c) Copyright 2019-2022 Xilinx, Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
/**
 * @file lz4_multibyte_decompress_stream.cpp
 * @brief Source for lz4 multibyte decompression stream kernel.
 *
 * This file is part of Vitis Compression Library.
 */
#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include "hls_stream.h"
#include <ap_int.h>

//L2_inc
#include "lz4_multibyte_decompress_stream.hpp"
//#include "xilLZ4decompressionStream_test.h"

const int c_parallelBit    = MULTIPLE_BYTES * 8;  // 64 //128
const int c_outstreamWidth = (OUTPUT_BYTES * 8) + OUTPUT_BYTES; // 72 //144
const int historySize      = HISTORY_SIZE;  // 65536
const int cout_parallelBit = OUTPUT_BYTES * 8;

extern "C" {

void xilLz4DecompressStream_B(hls::stream<ap_axiu<c_parallelBit, 0, 0, 0> >& inaxistream,
                              hls::stream<ap_axiu<cout_parallelBit, 0, 0, 0> >& outaxistream,
                              hls::stream<ap_axiu<32, 0, 0, 0> >& outaxistreamsize,
                              uint32_t inputSize, bool *magicHeaderError, bool modeBlk) {

#pragma HLS interface axis port = inaxistream
#pragma HLS interface axis port = outaxistream
#pragma HLS interface axis port = outaxistreamsize

#pragma HLS interface s_axilite port = inputSize        bundle = control
//#pragma HLS interface s_axilite port = magicHeaderError bundle = control
#pragma HLS interface s_axilite port = modeBlk          bundle = control
#pragma HLS interface s_axilite port = return           bundle = control

// 03/28/23 CMS, IS THIS NECESSARY?
#pragma HLS INTERFACE ap_none port = magicHeaderError

hls::stream<ap_uint<c_parallelBit> >    inStream("inStream");
hls::stream<ap_uint<c_outstreamWidth> > decompressedStream("decompressedStream");

#pragma HLS STREAM       variable = inStream depth = 32
#pragma HLS STREAM       variable = decompressedStream depth = 32
#pragma HLS BIND_STORAGE variable = inStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = decompressedStream type = FIFO impl = SRL

#pragma HLS dataflow

//L1_inc/hw/kernel_stream_utils.hpp
    xf::compression::details::kStreamRead<c_parallelBit>
        (inaxistream, inStream, inputSize);

//L1_inc/hw/lz4_decompress.hpp
    xf::compression::lz4DecompressEngine_opt3<MULTIPLE_BYTES, OUTPUT_BYTES, historySize>(inStream, decompressedStream, inputSize,
            magicHeaderError, modeBlk); // CMS 03/28/23

//L1_inc/hw/kernel_stream_utils.hpp
    xf::compression::details::kStreamWriteMultiByteSize<cout_parallelBit>
        (outaxistream, outaxistreamsize, decompressedStream);
}

}
