/*
 * (c) Copyright 2019-2022 Xilinx, Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * modified for block mode, ap 5-15-2023
 *
 */
#ifndef _XFCOMPRESSION_LZ4_DECOMPRESS_HPP_
#define _XFCOMPRESSION_LZ4_DECOMPRESS_HPP_

/**
 * @file lz4_decompress.hpp
 * @brief Header for modules used in LZ4 decompression kernel.
 *
 * This file is part of Vitis Data Compression Library.
 */

#include "hls_stream.h"
// L1_inc/hw
#include "lz_decompress.hpp"
// L1_inc/hw
#include "lz4_specs.hpp"
// L1_inc/hw
#include "inflate.hpp"
#include <ap_int.h>
#include <assert.h>
#include <stdint.h>

namespace xf {
namespace compression {

template <typename T>
T reg(T d) {
#pragma HLS PIPELINE II = 1
#pragma HLS INTERFACE ap_ctrl_none port = return
#pragma HLS INLINE off
    return d;
}

typedef struct lz4BlockInfo {
    uint32_t compressedSize;
    bool storedBlock;
} dt_lz4BlockInfo;


//______________________________________________________________________________
template <int PARALLEL_BYTES>
void lz4HeaderProcessing_C
    ( hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream,
      hls::stream<ap_uint<PARALLEL_BYTES * 8> >& outStream,
      hls::stream<dt_lz4BlockInfo>& blockInfoStream,
      const uint32_t inputSize, bool *magicHeaderError, bool modeBlk ) {

    if (inputSize == 0) return;

    const int c_parallelBit = PARALLEL_BYTES * 8;   // 64
    ap_uint<3 * c_parallelBit> inputWindow;         // 3*64, 24 bytes long
    ap_uint<c_parallelBit>     outStreamValue = 0;

    uint32_t origCompLen   = 0;
    uint32_t compLen       = 0;
    uint32_t blockSizeinKB = 0;
    bool     outFlag = false;

    // to send both compressSize and storedBlock data
    dt_lz4BlockInfo blockInfo;

    char magic_hdr[] = {MAGIC_BYTE_1, MAGIC_BYTE_2, MAGIC_BYTE_3, MAGIC_BYTE_4};
    char c;

    uint32_t readBytes = 0;
    uint8_t  inputIdx = 0;
    uint32_t processedBytes = 0;

//_________________________________________________________________________ block mode
// no frame header, block size, end mark, checksum. 
// just compressed data stream

if (modeBlk) {

    *magicHeaderError = false; 

    blockInfo.compressedSize = inputSize;
    blockInfo.storedBlock    = 0;         // not used
    blockInfoStream << blockInfo;

// what if data stream ends before reaching inputSize ?
L_blkmode: for (uint32_t i = 0; i < inputSize; i += PARALLEL_BYTES) {
    #pragma HLS PIPELINE II = 1
        ap_uint<c_parallelBit> input = inStream.read();  // read 8 Bytes
        outStream << input;
    }

    blockInfo.compressedSize = 0;
    blockInfoStream << blockInfo;

}  // if modeBlk

//_________________________________________________________________________ frame mode
// has frame header

else {

    // read 3 * 8bytes = 24 bytes
    for (uint8_t i = 0; i < 3; i++) {
    #pragma HLS PIPELINE II = 1
        inputWindow.range((i + 1) * c_parallelBit - 1, i * c_parallelBit) = inStream.read();
        readBytes += PARALLEL_BYTES;
    }

#ifdef DEBUG
    // print first 24 bytes read

    // std::cout << "<HEADER:info> " << std::hex<< inputWindow <<  std::endl;
    // 0x2420_6D69_6C65_640A_5145_2E38_F100_0092_DAA7_4064_184D_2204

    for (unsigned int i = 0; i < 24; i++) {
        //unsigned char x = (char)inputWindow.range(i*8+7, i*8);
        //char x = inputWindow.range(i*8+7, i*8);
        int x = (int)inputWindow.range(i*8+7, i*8);
        std::cout << "<HEADER: BYTE #" << std::dec << i << ">: " << std::hex << std::setw(2)<< x <<  std::endl;
    }
    std::cout << std::endl;
#endif

    *magicHeaderError = false; // CMS 3/28/2023

    // MAGIC_HEADER_SIZE = 4 from lz4_specs.hpp
    // BYTE #0,1,2,3 : Magic 

    for (uint32_t i = 0; i < MAGIC_HEADER_SIZE; i++) {
    // CHANGE: this to unroll later
    #pragma HLS PIPELINE II = 1
        int magicByte = (int)inputWindow.range((i + 1) * 8 - 1, i * 8);
        if (magicByte == magic_hdr[i])
            continue;
        else {
            //assert(0);
            *magicHeaderError = true; // CMS 3/28/2023
        }
    }

    // BYTE #4: flags, ignore? assume block checksum is not used?
    // BYTE #5: block max size
    // BYTE #6: header check sum
    // content size (uncompressed) is NOT included

    // BYTE #5
    c = (char)inputWindow.range(47, 40);

    switch (c) {
        case BSIZE_STD_64KB:
            blockSizeinKB = 64;
            break;
        case BSIZE_STD_256KB:
            blockSizeinKB = 256;
            break;
        case BSIZE_STD_1024KB:
            blockSizeinKB = 1024;
            break;
        case BSIZE_STD_4096KB:
            blockSizeinKB = 4096;
            break;
        default:         // CHANGE: maybe we should replace this assert?
            assert(0);
    }

#ifdef DEBUG
    std::cout << "<HEADER: BYTE #5> block size in KB: " << std::dec << blockSizeinKB <<  std::endl;
#endif

    // not used
    //blockSizeInBytes = blockSizeinKB * 1024;

    inputIdx += 7;         // 7
    processedBytes += 8;   // 8
    // readBytes should be 24

#ifdef DEBUG
std::cout << "<HEADER 1> inputIdx : " << std::dec <<  (int)inputIdx <<  std::endl;
#endif


//------------------------------------------------ start of block format, BYTE #7

#ifdef DEBUG
int bbb=0;
#endif

    // read block header for each block
L_blk_header:  for (; (processedBytes + inputIdx) < inputSize;) {

#ifdef DEBUG
std::cout << "================ block # : " << std::dec <<  bbb <<  std::endl;
bbb++;
#endif

        if ((inputIdx >= PARALLEL_BYTES)) {

            inputWindow >>= c_parallelBit;

            if (readBytes < inputSize) {
                ap_uint<c_parallelBit> input = inStream.read();  // read 8 Bytes
                inputWindow.range(3 * c_parallelBit - 1, 2 * c_parallelBit) = input;
                readBytes += PARALLEL_BYTES;
            }

            inputIdx       -= PARALLEL_BYTES;
            processedBytes += PARALLEL_BYTES;
#ifdef DEBUG
std::cout << "<HEADER 2> inputIdx : " << std::dec <<  (int)inputIdx <<  std::endl;
#endif

        }

//std::cout << "<HEADER INFO> inputIdx : " << std::dec <<  (int)inputIdx <<  std::endl;
//std::cout << "<HEADER INFO> processedBytes : " << std::dec <<  processedBytes <<  std::endl;

        // BYTE #7,8,9,10: block size (compressed), 4 bytes = ininputWindow(56+32-1:56)
        ap_uint<32> compressedSize = inputWindow >> (inputIdx * 8);

#ifdef DEBUG
std::cout << "<HEADER INFO> compressed size : " << std::dec <<  compressedSize <<  std::endl;
std::cout << "<HEADER INFO> compressed size(hex) : " << std::hex <<  compressedSize <<  std::endl;
#endif

        inputIdx += 4; // 7+4=11, magic(4B), flag(1B), BD(1B), header checksum(1B), BLK size(4B)

#ifdef DEBUG
std::cout << "<HEADER 3> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif

        // "1" means uncompressed
        bool storedBlkFlg = (compressedSize.range(31, 31) == 1) ? true : false;

        // 2^24 = 4MB maximum
        ap_uint<32> compressedSizeMask = 0x00FFFFFF;
        compressedSize = compressedSize & compressedSizeMask; // remove MSB (uncompressed flag + pad)

        compLen = compressedSize;
        blockInfo.compressedSize = compressedSize;

        // compressed?
        if (storedBlkFlg) {
            blockInfo.storedBlock = 1;
        } else {
            blockInfo.storedBlock = 0;
        }
        // write compress length to outSizeStream
        blockInfoStream << blockInfo;

        uint32_t len = compLen;

//return;


// read compressed data 8B at a time
L_read: for (uint32_t i = 0; i < compLen; i += PARALLEL_BYTES) {
#pragma HLS PIPELINE II = 1
            if ((inputIdx >= PARALLEL_BYTES)) {

                inputWindow >>= c_parallelBit;

                if (readBytes < inputSize) {
                    ap_uint<c_parallelBit> input = inStream.read();  // read 8 Bytes
                    readBytes += PARALLEL_BYTES;
                    inputWindow.range(3 * c_parallelBit - 1, 2 * c_parallelBit) = input;
                }

                inputIdx       -= PARALLEL_BYTES;
                processedBytes += PARALLEL_BYTES;
#ifdef DEBUG
if (i<12) 
std::cout << "<HEADER 3> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif

            }  // if ((inputIdx >= PARALLEL_BYTES)) 

            outStreamValue = inputWindow >> (inputIdx * 8);
            outStream << outStreamValue;

            if (len >= PARALLEL_BYTES) {
                inputIdx += PARALLEL_BYTES;
                len      -= PARALLEL_BYTES;
#ifdef DEBUG
if (i<12) 
std::cout << "<HEADER 4> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif
            } else {
                inputIdx += len;
#ifdef DEBUG
if (i<12) 
std::cout << "<HEADER 5> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif
                len       = 0;
            }
        }  // L_read

#ifdef DEBUG
int yyy = processedBytes + inputIdx;
std::cout << "<HEADER INFO> processedBytes + inputIdx = : " << std::dec <<  yyy <<  std::endl;
std::cout << "<HEADER INFO> inputSize = : " << std::dec << inputSize <<  std::endl;
#endif
    }      // L_blk_header

    blockInfo.compressedSize = 0;
    // writing 0 to indicate end of data
    blockInfoStream << blockInfo;

}          // modeBlk = false

}


//______________________________________________________________________________
template <int PARALLEL_BYTES>
void lz4HeaderProcessing_B
    ( hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream,
      hls::stream<ap_uint<PARALLEL_BYTES * 8> >& outStream,
      hls::stream<dt_lz4BlockInfo>& blockInfoStream,
      const uint32_t inputSize, bool *magicHeaderError, bool modeBlk ) {

    if (inputSize == 0) return;

    const int c_parallelBit = PARALLEL_BYTES * 8;   // 64
    ap_uint<3 * c_parallelBit> inputWindow;         // 3*64, 24 bytes long
    ap_uint<c_parallelBit>     outStreamValue = 0;

    uint32_t origCompLen   = 0;
    uint32_t compLen       = 0;
    uint32_t blockSizeinKB = 0;
    bool     outFlag = false;

    // to send both compressSize and storedBlock data
    dt_lz4BlockInfo blockInfo;

    char magic_hdr[] = {MAGIC_BYTE_1, MAGIC_BYTE_2, MAGIC_BYTE_3, MAGIC_BYTE_4};
    char c;

    uint32_t readBytes = 0;
    uint8_t  inputIdx = 0;
    //uint32_t inputIdx = 0;
    uint32_t processedBytes = 0;

#ifdef DEBUG
    uint32_t nofBlks = 0;
#endif

    // read 3 * 8bytes = 24 bytes
    for (uint8_t i = 0; i < 3; i++) {
    #pragma HLS PIPELINE II = 1
        inputWindow.range((i + 1) * c_parallelBit - 1, i * c_parallelBit) = inStream.read();
        readBytes += PARALLEL_BYTES;
    }

#ifdef DEBUG
    // print first 24 bytes read

    // std::cout << "<HEADER:info> " << std::hex<< inputWindow <<  std::endl;
    // 0x2420_6D69_6C65_640A_5145_2E38_F100_0092_DAA7_4064_184D_2204

    for (unsigned int i = 0; i < 24; i++) {
        //unsigned char x = (char)inputWindow.range(i*8+7, i*8);
        //char x = inputWindow.range(i*8+7, i*8);
        int x = (int)inputWindow.range(i*8+7, i*8);
        std::cout << "<HEADER: BYTE #" << std::dec << i << ">: " << std::hex << std::setw(2)<< x <<  std::endl;
    }
    std::cout << std::endl;
#endif


if (modeBlk == false) {
//------------------------------------------------ frame format
    *magicHeaderError = false; // CMS 3/28/2023

    // MAGIC_HEADER_SIZE = 4 from lz4_specs.hpp
    // BYTE #0,1,2,3 : Magic 

    for (uint32_t i = 0; i < MAGIC_HEADER_SIZE; i++) {
    // CHANGE: this to unroll later
    #pragma HLS PIPELINE II = 1
        int magicByte = (int)inputWindow.range((i + 1) * 8 - 1, i * 8);
        if (magicByte == magic_hdr[i])
            continue;
        else {
            //assert(0);
            *magicHeaderError = true; // CMS 3/28/2023
        }
    }

    // BYTE #4: flags, ignore? assume block checksum is not used?
    // BYTE #5: block max size
    // BYTE #6: header check sum
    // content size (uncompressed) is NOT included

    // BYTE #5
    c = (char)inputWindow.range(47, 40);

    switch (c) {
        case BSIZE_STD_64KB:
            blockSizeinKB = 64;
            break;
        case BSIZE_STD_256KB:
            blockSizeinKB = 256;
            break;
        case BSIZE_STD_1024KB:
            blockSizeinKB = 1024;
            break;
        case BSIZE_STD_4096KB:
            blockSizeinKB = 4096;
            break;
        default:         // CHANGE: maybe we should replace this assert?
            assert(0);
    }

#ifdef DEBUG
    std::cout << "<HEADER: BYTE #5> block size in KB: " << std::dec << blockSizeinKB <<  std::endl;
#endif

    // not used
    //blockSizeInBytes = blockSizeinKB * 1024;

    inputIdx += 7;         // 7
    processedBytes += 8;   // 8
    // readBytes should be 24

#ifdef DEBUG
std::cout << "<HEADER 1> inputIdx : " << std::dec <<  (int)inputIdx <<  std::endl;
#endif

}  // if (modeBlk=false)
else {

    //inputIdx       += 0;              // start reading from 0th byte
    //readBytes      += PARALLEL_BYTES;
    processedBytes += 8;         

}

//------------------------------------------------ start of block format, BYTE #7

#ifdef DEBUG
int bbb=0;
#endif

    // read block header for each block
L_blk_header:  for (; (processedBytes + inputIdx) < inputSize;) {

#ifdef DEBUG
std::cout << "================ block # : " << std::dec <<  bbb <<  std::endl;
bbb++;
#endif

        if ((inputIdx >= PARALLEL_BYTES)) {

            inputWindow >>= c_parallelBit;

            if (readBytes < inputSize) {
                ap_uint<c_parallelBit> input = inStream.read();  // read 8 Bytes
                inputWindow.range(3 * c_parallelBit - 1, 2 * c_parallelBit) = input;
                readBytes += PARALLEL_BYTES;
            }

            inputIdx       -= PARALLEL_BYTES;
            processedBytes += PARALLEL_BYTES;
#ifdef DEBUG
std::cout << "<HEADER 2> inputIdx : " << std::dec <<  (int)inputIdx <<  std::endl;
#endif

        }

//std::cout << "<HEADER INFO> inputIdx : " << std::dec <<  (int)inputIdx <<  std::endl;
//std::cout << "<HEADER INFO> processedBytes : " << std::dec <<  processedBytes <<  std::endl;

        // BYTE #7,8,9,10: block size (compressed), 4 bytes = ininputWindow(56+32-1:56)
        ap_uint<32> compressedSize = inputWindow >> (inputIdx * 8);

#ifdef DEBUG
std::cout << "<HEADER INFO> compressed size : " << std::dec <<  compressedSize <<  std::endl;
std::cout << "<HEADER INFO> compressed size(hex) : " << std::hex <<  compressedSize <<  std::endl;
#endif

        inputIdx += 4; // 7+4=11, magic(4B), flag(1B), BD(1B), header checksum(1B), BLK size(4B)

#ifdef DEBUG
std::cout << "<HEADER 3> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif

        // "1" means uncompressed
        bool storedBlkFlg = (compressedSize.range(31, 31) == 1) ? true : false;

        // 2^24 = 4MB maximum
        ap_uint<32> compressedSizeMask = 0x00FFFFFF;
        compressedSize = compressedSize & compressedSizeMask; // remove MSB (uncompressed flag + pad)

        compLen = compressedSize;
        blockInfo.compressedSize = compressedSize;

        // compressed?
        if (storedBlkFlg) {
            blockInfo.storedBlock = 1;
        } else {
            blockInfo.storedBlock = 0;
        }
        // write compress length to outSizeStream
        blockInfoStream << blockInfo;

        uint32_t len = compLen;

//return;


// read compressed data 8B at a time
L_read: for (uint32_t i = 0; i < compLen; i += PARALLEL_BYTES) {
#pragma HLS PIPELINE II = 1
            if ((inputIdx >= PARALLEL_BYTES)) {

                inputWindow >>= c_parallelBit;

                if (readBytes < inputSize) {
                    ap_uint<c_parallelBit> input = inStream.read();  // read 8 Bytes
                    readBytes += PARALLEL_BYTES;
                    inputWindow.range(3 * c_parallelBit - 1, 2 * c_parallelBit) = input;
                }

                inputIdx       -= PARALLEL_BYTES;
                processedBytes += PARALLEL_BYTES;
#ifdef DEBUG
if (i<12) 
std::cout << "<HEADER 3> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif

            }  // if ((inputIdx >= PARALLEL_BYTES)) 

            outStreamValue = inputWindow >> (inputIdx * 8);
            outStream << outStreamValue;

            if (len >= PARALLEL_BYTES) {
                inputIdx += PARALLEL_BYTES;
                len      -= PARALLEL_BYTES;
#ifdef DEBUG
if (i<12) 
std::cout << "<HEADER 4> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif
            } else {
                inputIdx += len;
#ifdef DEBUG
if (i<12) 
std::cout << "<HEADER 5> inputIdx : " << std::dec <<  (int)inputIdx << "  " << processedBytes<< std::endl;
#endif
                len       = 0;
            }
        }  // for (.... i < compLen)

#ifdef DEBUG
int yyy = processedBytes + inputIdx;
std::cout << "<HEADER INFO> processedBytes + inputIdx = : " << std::dec <<  yyy <<  std::endl;
std::cout << "<HEADER INFO> inputSize = : " << std::dec << inputSize <<  std::endl;
#endif
    }      // for (; (processedBytes + inputIdx) < inputSize;) 

    blockInfo.compressedSize = 0;
    // writing 0 to indicate end of data
    blockInfoStream << blockInfo;

}


//______________________________________________________________________________
// original 

template <int PARALLEL_BYTES>
void lz4HeaderProcessing(hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream,
                         hls::stream<ap_uint<PARALLEL_BYTES * 8> >& outStream,
                         hls::stream<dt_lz4BlockInfo>& blockInfoStream,
                         const uint32_t inputSize,
						 bool *magicHeaderError ) { // CMS 3/28/2023

    if (inputSize == 0) return;

    const int c_parallelBit = PARALLEL_BYTES * 8; // 64
    ap_uint<3 * c_parallelBit> inputWindow;       // 3*64
    ap_uint<c_parallelBit>     outStreamValue = 0;

    uint32_t origCompLen = 0, compLen = 0, blockSizeinKB = 0;
    bool     outFlag = false;

    // to send both compressSize and storedBlock data
    dt_lz4BlockInfo blockInfo;

    // read 3 * 8bytes = 24 bytes
    uint32_t readBytes = 0;

    for (uint8_t i = 0; i < 3; i++) {
#pragma HLS PIPELINE II = 1
        inputWindow.range((i + 1) * c_parallelBit - 1, i * c_parallelBit) = inStream.read();
        readBytes += PARALLEL_BYTES;
    }

    // Read magic header 4 bytes
    *magicHeaderError = false; // CMS 3/28/2023
    char magic_hdr[] = {MAGIC_BYTE_1, MAGIC_BYTE_2, MAGIC_BYTE_3, MAGIC_BYTE_4};

    // MAGIC_HEADER_SIZE = 4 from lz4_specs.hpp
    for (uint32_t i = 0; i < MAGIC_HEADER_SIZE; i++) {
#pragma HLS PIPELINE II = 1
        int magicByte = (int)inputWindow.range((i + 1) * 8 - 1, i * 8);
        if (magicByte == magic_hdr[i])
            continue;
        else {
            //assert(0);
            *magicHeaderError = true; // CMS 3/28/2023
        }
    }

    // 5th byte: flags
    // 6th byte: block max size
    char c = (char)inputWindow.range(47, 40);
    switch (c) {
        case BSIZE_STD_64KB:
            blockSizeinKB = 64;
            break;
        case BSIZE_STD_256KB:
            blockSizeinKB = 256;
            break;
        case BSIZE_STD_1024KB:
            blockSizeinKB = 1024;
            break;
        case BSIZE_STD_4096KB:
            blockSizeinKB = 4096;
            break;
        default:
            assert(0);
    }

    uint32_t blockSizeInBytes = blockSizeinKB * 1024;

    // readBytes is 24
    uint8_t  inputIdx = 7;
    uint32_t processedBytes = 8;
    //inputIdx += 7;
    //processedBytes += 8;

    // loops only when number of block is more than one?
    // for (; (processedBytes + inputIdx) < inputSize;) {
    {

        if ((inputIdx >= PARALLEL_BYTES)) {
            inputWindow >>= c_parallelBit;
            if (readBytes < inputSize) {
                ap_uint<c_parallelBit> input = inStream.read();
                readBytes += PARALLEL_BYTES;
                inputWindow.range(3 * c_parallelBit - 1, 2 * c_parallelBit) = input;
            }
            inputIdx = inputIdx - PARALLEL_BYTES;
            processedBytes += PARALLEL_BYTES;
        }

        //uint32_t chunkSize = 0;

        //------------------------ start of Block 

        // block size (compressed) = ininputWindow(48+32-1:48)
        ap_uint<32> compressedSize = inputWindow >> (inputIdx * 8);
        inputIdx += 4; // 7+4=11, magic(4B), flag(1B), BD(1B), BLK size(4B)

        // "1" means uncompressed
        bool storedBlkFlg = (compressedSize.range(31, 31) == 1) ? true : false;

// CMS 3/13/2023 begin mods /////////////////////////////////////////////

        // 2^20 = 1MB is maximum?
        ap_uint<32> compressedSizeMask = 0x00FFFFFF;
        compressedSize = compressedSize & compressedSizeMask; // remove MSB (uncompressed flag + pad)

/*
        uint32_t tmp = compressedSize;
        tmp >>= 24;
        if (tmp == 128) {
            uint8_t b1 = compressedSize;
            uint8_t b2 = compressedSize >> 8;
            uint8_t b3 = compressedSize >> 16;

            if (b3 == 1) {
                compressedSize = blockSizeInBytes;
            } else {
                uint16_t size = 0;
                size = b2;
                size <<= 8;
                uint16_t temp = b1;
                size |= temp;
                compressedSize = size;
            }
        }
*/
// CMS 3/13/2023 end mods /////////////////////////////////////////////

        compLen = compressedSize;
        blockInfo.compressedSize = compressedSize;

        // compressed?
        if (storedBlkFlg) {
            blockInfo.storedBlock = 1;
        } else {
            blockInfo.storedBlock = 0;
        }
        // write compress length to outSizeStream
        blockInfoStream << blockInfo;

        uint32_t len = compLen;
        for (uint32_t blockData = 0; blockData < compLen; blockData += PARALLEL_BYTES) {
#pragma HLS PIPELINE II = 1
            if ((inputIdx >= PARALLEL_BYTES)) {
                inputWindow >>= c_parallelBit;
                if (readBytes < inputSize) {
                    ap_uint<c_parallelBit> input = inStream.read();
                    readBytes += PARALLEL_BYTES;
                    inputWindow.range(3 * c_parallelBit - 1, 2 * c_parallelBit) = input;
                }
                inputIdx = inputIdx - PARALLEL_BYTES;
                processedBytes += PARALLEL_BYTES;
            }

            outStreamValue = inputWindow >> (inputIdx * 8);
            outStream << outStreamValue;

            if (len >= PARALLEL_BYTES) {
                inputIdx += PARALLEL_BYTES;
                len -= PARALLEL_BYTES;
            } else {
                inputIdx += len;
                len = 0;
            }
        }  // for (.... blockData < compLen)

    }      // for (; (processedBytes + inputIdx) < inputSize;) 

    blockInfo.compressedSize = 0;
    // writing 0 to indicate end of data
    blockInfoStream << blockInfo;
}

//______________________________________________________________________________
/**
 * @brief This module reads the compressed data from input stream
 * and decodes the offset, match length and literals by processing
 * in various decompress states.
 *
 *
 * @param inStream Input stream 8bit
 * @param outStream Output stream 32bit
 * @param input_size Input size
 */
inline void lz4Decompress(hls::stream<ap_uint<8> >& inStream,
                          hls::stream<ap_uint<32> >& outStream,
                          uint32_t input_size) {
    enum lz4DecompressStates { READ_TOKEN, READ_LIT_LEN, READ_LITERAL, READ_OFFSET0, READ_OFFSET1, READ_MATCH_LEN };
    enum lz4DecompressStates next_state = READ_TOKEN;
    ap_uint<8> nextValue;
    ap_uint<16> offset;
    ap_uint<32> decompressdOut = 0;
    uint32_t lit_len = 0;
    uint32_t match_len = 0;
lz4_decompressr:
    for (uint32_t i = 0; i < input_size; i++) {
#pragma HLS PIPELINE II = 1
        ap_uint<8> inValue = inStream.read();
        if (next_state == READ_TOKEN) {
            lit_len = inValue.range(7, 4);
            match_len = inValue.range(3, 0);
            if (lit_len == 0xF) {
                next_state = READ_LIT_LEN;
            } else if (lit_len) {
                next_state = READ_LITERAL;
            } else {
                next_state = READ_OFFSET0;
            }
        } else if (next_state == READ_LIT_LEN) {
            lit_len += inValue;
            if (inValue != 0xFF) {
                next_state = READ_LITERAL;
            }
        } else if (next_state == READ_LITERAL) {
            ap_uint<32> outValue = 0;
            outValue.range(7, 0) = inValue;
            outStream << outValue;
            lit_len--;
            if (lit_len == 0) {
                next_state = READ_OFFSET0;
            }
        } else if (next_state == READ_OFFSET0) {
            offset.range(7, 0) = inValue;
            next_state = READ_OFFSET1;
        } else if (next_state == READ_OFFSET1) {
            offset.range(15, 8) = inValue;
            if (match_len == 0xF) {
                next_state = READ_MATCH_LEN;
            } else {
                next_state = READ_TOKEN;
                ap_uint<32> outValue = 0;
                outValue.range(31, 16) = (match_len + 3); //+3 for LZ4 standard
                outValue.range(15, 0) = (offset - 1);     //-1 for LZ4 standard
                outStream << outValue;
            }
        } else if (next_state == READ_MATCH_LEN) {
            match_len += inValue;
            if (inValue != 0xFF) {
                ap_uint<32> outValue = 0;
                outValue.range(31, 16) = (match_len + 3); //+3 for LZ4 standard
                outValue.range(15, 0) = (offset - 1);     //-1 for LZ4 standard
                outStream << outValue;
                next_state = READ_TOKEN;
            }
        }
    }
}

//______________________________________________________________________________
inline void lz4DecompressSimple(hls::stream<ap_uint<8> >& inStream,
                                hls::stream<ap_uint<32> >& outStream,
                                uint32_t input_size,
                                bool uncomp_flag) {
    enum lz4DecompressStates { READ_TOKEN, READ_LIT_LEN, READ_LITERAL, READ_OFFSET0, READ_OFFSET1, READ_MATCH_LEN };
    enum lz4DecompressStates next_state = READ_TOKEN;
    ap_uint<8> nextValue;
    ap_uint<16> offset;
    ap_uint<32> decompressdOut = 0;
    uint32_t lit_len = 0;
    uint32_t match_len = 0;
    if (uncomp_flag == 1) {
        next_state = READ_LITERAL;
        lit_len = input_size;
    }
lz4_decompressr:
    for (uint32_t i = 0; i < input_size; i++) {
#pragma HLS PIPELINE II = 1
        ap_uint<8> inValue = inStream.read();
        if (next_state == READ_TOKEN) {
            lit_len = inValue.range(7, 4);
            match_len = inValue.range(3, 0);
            if (lit_len == 0xF) {
                next_state = READ_LIT_LEN;
            } else if (lit_len) {
                next_state = READ_LITERAL;
            } else {
                next_state = READ_OFFSET0;
            }
        } else if (next_state == READ_LIT_LEN) {
            lit_len += inValue;
            if (inValue != 0xFF) {
                next_state = READ_LITERAL;
            }
        } else if (next_state == READ_LITERAL) {
            ap_uint<32> outValue = 0;
            outValue.range(7, 0) = inValue;
            outStream << outValue;
            lit_len--;
            if (lit_len == 0) {
                next_state = READ_OFFSET0;
            }
        } else if (next_state == READ_OFFSET0) {
            offset.range(7, 0) = inValue;
            next_state = READ_OFFSET1;
        } else if (next_state == READ_OFFSET1) {
            offset.range(15, 8) = inValue;
            if (match_len == 0xF) {
                next_state = READ_MATCH_LEN;
            } else {
                next_state = READ_TOKEN;
                ap_uint<32> outValue = 0;
                outValue.range(31, 16) = (match_len + 3); //+3 for LZ4 standard
                outValue.range(15, 0) = (offset - 1);     //-1 for LZ4 standard
                outStream << outValue;
            }
        } else if (next_state == READ_MATCH_LEN) {
            match_len += inValue;
            if (inValue != 0xFF) {
                ap_uint<32> outValue = 0;
                outValue.range(31, 16) = (match_len + 3); //+3 for LZ4 standard
                outValue.range(15, 0) = (offset - 1);     //-1 for LZ4 standard
                outStream << outValue;
                next_state = READ_TOKEN;
            }
        }
    }
}

//______________________________________________________________________________
template <int PARALLEL_BYTES, class SIZE_DT = uint32_t>
inline void lz4MultiByteDecompress(
    hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream,
    hls::stream<SIZE_DT>&                      litlenStream,
    hls::stream<ap_uint<PARALLEL_BYTES * 8> >& litStream,
    hls::stream<ap_uint<16> >&                 offsetStream,
    hls::stream<SIZE_DT>&                      matchlenStream,
    hls::stream<dt_lz4BlockInfo>&              blockInfoStream) {

enum lz4DecompressStates { READ_TOKEN, READ_LIT_LEN, READ_LITERAL, READ_OFFSET, READ_MATCH_LEN };

for (dt_lz4BlockInfo bInfo = blockInfoStream.read(); bInfo.compressedSize != 0; bInfo = blockInfoStream.read()) {
        uint32_t input_size = bInfo.compressedSize;

// DEBUG
// std::cout << "<ByteDecompress 1> input_size : " << std::dec <<  (int)input_size << std::endl;

        enum lz4DecompressStates next_state = READ_TOKEN;

        const int c_parallelBit = PARALLEL_BYTES * 8;
        uint8_t   token_match_len = 0;
        uint8_t   token_lit_len   = 0;
        uint8_t   input_index     = 0;
        int8_t    output_index    = 0;
        SIZE_DT   lit_len   = 0;
        SIZE_DT   match_len = 0;
        bool      outFlag;

        ap_uint<16> offset;
        ap_uint<c_parallelBit> outStreamValue;
        ap_uint<c_parallelBit> inValue;

        ap_uint<2 * c_parallelBit> input_window;

        bool storedBlock = bInfo.storedBlock;
        if (storedBlock) {
            lit_len = input_size;
            litlenStream << lit_len;
            matchlenStream << 0;
            offsetStream << 0;
            next_state = READ_LITERAL;
        }

        ap_uint<2> numItr = (input_size <= PARALLEL_BYTES) ? 1 : 2;
        // Pre-read two data from the stream (two based on the READ_TOKEN)
        for (int i = 0; i < numItr; i++) {
#pragma HLS PIPELINE II = 1
            inValue = inStream.read();
// DEBUG
// std::cout << "<ByteDecompress 2> inValue : " << std::hex <<  inValue << std::endl;

            input_window.range(((i + 1) * c_parallelBit) - 1, i * c_parallelBit) = inValue;
        }

        // Initialize the loop readBytes variable to input_window buffer size as
        // that much data is already read from stream
        uint32_t readBytes = 2 * PARALLEL_BYTES;
        uint32_t processedBytes = 0;

    lz4_decompressr:
        for (; ((processedBytes + input_index) < input_size);) {
#pragma HLS PIPELINE II = 1
            uint8_t incrInputIdx = 0;
            outFlag = false;

            // READ TOKEN stage
            if (next_state == READ_TOKEN) {
                ap_uint<8> token_value = input_window >> (input_index * 8);
                token_lit_len = token_value.range(7, 4);
                token_match_len = token_value.range(3, 0);
                bool c0 = (token_lit_len == 0xF);
                incrInputIdx = 1;
                lit_len = token_lit_len;

                if (c0) {
                    next_state = READ_LIT_LEN;
                } else if (lit_len) {
                    next_state = READ_LITERAL;
                    litlenStream << lit_len;
                    matchlenStream << 0;
                    offsetStream << 0;
                } else {
                    next_state = READ_OFFSET;
                }
            } else if (next_state == READ_LIT_LEN) {
                ap_uint<8> token_value = input_window >> (input_index * 8);
                incrInputIdx = 1;
                lit_len += token_value;

                if (token_value == 0xFF) {
                    next_state = READ_LIT_LEN;
                } else {
                    next_state = READ_LITERAL;
                    litlenStream << lit_len;
                    matchlenStream << 0;
                    offsetStream << 0;
                }
            } else if (next_state == READ_LITERAL) {
                outFlag = true;
                outStreamValue = input_window >> (input_index * 8);
                uint32_t localLitLen = lit_len;
                if (localLitLen <= PARALLEL_BYTES) {
                    incrInputIdx = lit_len;
                    lit_len = 0;
                    next_state = READ_OFFSET;
                } else {
                    incrInputIdx = PARALLEL_BYTES;
                    lit_len -= PARALLEL_BYTES;
                    next_state = READ_LITERAL;
                }
            } else if (next_state == READ_OFFSET) {
                offset = input_window >> (input_index * 8);
                bool c0 = (token_match_len == 0xF);
                incrInputIdx = 2;
                match_len = token_match_len + 4; //+4 because of LZ4 standard

                if (c0) {
                    next_state = READ_MATCH_LEN;
                } else {
                    next_state = READ_TOKEN;
                    litlenStream << 0;
                    matchlenStream << match_len;
                    offsetStream << offset;
                }
            } else if (next_state == READ_MATCH_LEN) {
                ap_uint<8> token_value = input_window >> (input_index * 8);
                incrInputIdx = 1;
                match_len += token_value;

                if (token_value == 0xFF) {
                    next_state = READ_MATCH_LEN;
                } else {
                    next_state = READ_TOKEN;
                    litlenStream << 0;
                    matchlenStream << match_len;
                    offsetStream << offset;
                }
            } else {
                assert(0);
            }

            input_index += incrInputIdx;
            bool inputIdxFlag = reg<bool>((input_index >= PARALLEL_BYTES));
            // write to input stream based on PARALLEL BYTES
            if (inputIdxFlag) {
                input_window >>= c_parallelBit;
                input_index -= PARALLEL_BYTES;
                processedBytes += PARALLEL_BYTES;
                if (readBytes < input_size) {
                    ap_uint<c_parallelBit> input = inStream.read();  
                    readBytes += PARALLEL_BYTES;
                    input_window.range(2 * c_parallelBit - 1, c_parallelBit) = input;
                }
            }

            if (outFlag) {
                litStream << outStreamValue;
                outFlag = false;
            }
            printf("\n");
        }
    }//end block

    if (!blockInfoStream.empty()) dt_lz4BlockInfo bInfo = blockInfoStream.read();

    // signalling end of transaction
    litlenStream << 0;
    matchlenStream << 0;
    offsetStream << 0;
    // printf("\nInIdx: %d \t outIdx: %d \t Input_size: %d \t read_from_stream: %d  \t written_to_stream: %d \t
    // output_count: %d\n",input_index, output_index,input_size,readBytes, out_written, output_count);
}

//______________________________________________________________________________
// <8, 65536>
// 64b inStream, 72b outStream
template <int PARALLEL_BYTES, int HISTORY_SIZE>
void lz4CoreDecompressEngine(hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream, 
                             hls::stream<ap_uint<(PARALLEL_BYTES * 8) + PARALLEL_BYTES> >& outStream,
                             hls::stream<uint32_t>& blockSizeStream) {

typedef ap_uint<PARALLEL_BYTES * 8> uintV_t;
typedef ap_uint<16>                 offset_dt;

hls::stream<uint32_t>        litlenStream("litlenStream");
hls::stream<uintV_t>         litStream("litStream");
hls::stream<offset_dt>       offsetStream("offsetStream");
hls::stream<uint32_t>        matchlenStream("matchlenStream");
hls::stream<dt_lz4BlockInfo> blockInfoStream("blockInfoStream");
hls::stream<ap_uint<27> >    lzInfoStream("lzInfoStream");

#pragma HLS STREAM variable = litlenStream depth = 16
#pragma HLS STREAM variable = litStream depth = 256
#pragma HLS STREAM variable = offsetStream depth = 16
#pragma HLS STREAM variable = matchlenStream depth = 16
#pragma HLS STREAM variable = blockInfoStream depth = 4
#pragma HLS STREAM variable = lzInfoStream depth = 4

#pragma HLS BIND_STORAGE variable = litlenStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = litStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = offsetStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = matchlenStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = blockInfoStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = lzInfoStream type = FIFO impl = SRL

    dt_lz4BlockInfo blockInfo;
    for (int i = 0; i < 2; i++) {
        blockInfo.compressedSize = blockSizeStream.read();
        blockInfo.storedBlock = 0;
        blockInfoStream << blockInfo;
    }
#pragma HLS dataflow
    lz4MultiByteDecompress<PARALLEL_BYTES>(inStream, litlenStream, litStream, offsetStream, matchlenStream,
                                           blockInfoStream);
    details::lzPreProcessingUnitLL<uint32_t, PARALLEL_BYTES>(litlenStream, matchlenStream, offsetStream, lzInfoStream);
    lzMultiByteDecompressLL<PARALLEL_BYTES, HISTORY_SIZE, 16, ap_uint<17> >(litStream, lzInfoStream, outStream);
}

//______________________________________________________________________________
// <8, 65536>
// 64b inStream, 72b outStream

template <int PARALLEL_BYTES, int HISTORY_SIZE>
void lz4DecompressEngine
    (hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream,
     hls::stream<ap_uint<(PARALLEL_BYTES * 8) + PARALLEL_BYTES> >& outStream,
     const uint32_t _input_size,
	bool *magicHeaderError) { // CMS 03/28/23

typedef ap_uint<PARALLEL_BYTES * 8> uintV_t; // 64b
typedef ap_uint<16> offset_dt;

uint32_t input_size1 = _input_size;

hls::stream<uint32_t>        litlenStream("litlenStream");
hls::stream<uintV_t>         litStream("litStream");
hls::stream<uintV_t>         headerStream("headerStream");
hls::stream<offset_dt>       offsetStream("offsetStream");
hls::stream<uint32_t>        matchlenStream("matchlenStream");
hls::stream<dt_lz4BlockInfo> blockInfoStream("blockInfoStream");
hls::stream<ap_uint<27> >    lzInfoStream("lzInfoStream");

#pragma HLS STREAM variable = litlenStream depth = 16
#pragma HLS STREAM variable = headerStream depth = 16
#pragma HLS STREAM variable = litStream depth = 256
#pragma HLS STREAM variable = offsetStream depth = 16
#pragma HLS STREAM variable = matchlenStream depth = 16
#pragma HLS STREAM variable = blockInfoStream depth = 4
#pragma HLS STREAM variable = lzInfoStream depth = 4

#pragma HLS BIND_STORAGE variable = litlenStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = litStream    type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = headerStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = offsetStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = matchlenStream  type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = blockInfoStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = lzInfoStream    type = FIFO impl = SRL

// bool magicHeaderError;

#pragma HLS dataflow

lz4HeaderProcessing<PARALLEL_BYTES>
    (inStream, headerStream, blockInfoStream, input_size1, magicHeaderError);  // CMS 3/28/2023

lz4MultiByteDecompress<PARALLEL_BYTES, uint32_t>
    (headerStream, litlenStream, litStream, offsetStream, matchlenStream, blockInfoStream);

//L1_inc/hw/inflate.hpp
details::lzPreProcessingUnitLL<uint32_t, PARALLEL_BYTES>
    (litlenStream, matchlenStream, offsetStream, lzInfoStream);

//L1_inc/hw/lz_decompress.hpp
lzMultiByteDecompressLL<PARALLEL_BYTES, HISTORY_SIZE, 16, ap_uint<17> >
    (litStream, lzInfoStream, outStream);

}

template <int PARALLEL_BYTES, class SIZE_DT = uint32_t>
inline void lz4MultiByteDecompress_opt1(
    hls::stream<ap_uint<PARALLEL_BYTES * 8> >& inStream,
    hls::stream<SIZE_DT>&                      litlenStream,
    hls::stream<ap_uint<PARALLEL_BYTES * 8> >& litStream,
    hls::stream<ap_uint<16> >&                 offsetStream,
    hls::stream<SIZE_DT>&                      matchlenStream,
    hls::stream<dt_lz4BlockInfo>&              blockInfoStream) {

	dt_lz4BlockInfo bInfo;
	const int c_parallelBit = PARALLEL_BYTES * 8;

    enum lz4DecompressStates { READ_TOKEN, READ_LIT_LEN, READ_LITERAL, READ_OFFSET, READ_MATCH_LEN, READ_LITLEN_LIT_OFFSET };
        int stt_num_token = 0;
        int stt_i_loop = 0;
        int stt_lit_len = 0;
        int stt_match_len = 0;
        int stt_input_index=0;

        int stt_read_in = 0;
        int stt_write_lit = 0;
        int stt_write_tk = 0;
        int stt_lit_len_all = 0;
        int stt_match_len_all = 0;
	for ( bInfo = blockInfoStream.read(); bInfo.compressedSize != 0; bInfo = blockInfoStream.read()) {
		uint32_t input_size = bInfo.compressedSize;

        enum lz4DecompressStates next_state = READ_LITLEN_LIT_OFFSET;

        const int c_parallelBit = PARALLEL_BYTES * 8;
        uint8_t   token_match_len    = 0;
        uint8_t   token_match_len_p4 = 0;
        uint8_t   token_lit_len      = 0;
        uint8_t   token_lit_len_p1   = 0;
        uint8_t   token_lit_len_p3   = 0;
        uint8_t   input_index        = 0;
        uint8_t   input_index_offset = 0;
        int8_t    output_index       = 0;
        SIZE_DT   lit_len   = 0;
        SIZE_DT   match_len = 0;
        bool      outFlag;

        ap_uint<16> offset;
        ap_uint<c_parallelBit> outStreamValue;
        ap_uint<c_parallelBit> inValue;

        ap_uint<2 * c_parallelBit> input_window;

        bool storedBlock = bInfo.storedBlock;
        if (storedBlock) {
            lit_len = input_size;
            litlenStream << lit_len;
            matchlenStream << 0;
            offsetStream << 0;
            next_state = READ_LITERAL;
#ifdef STT_M2
                    stt_write_tk++;
#endif
        }

        ap_uint<2> numItr = (input_size <= PARALLEL_BYTES) ? 1 : 2;
        // Pre-read two data from the stream (two based on the READ_TOKEN)
        for (int i = 0; i < numItr; i++) {
#pragma HLS PIPELINE II = 1
            inValue = inStream.read();
// DEBUG
// std::cout << "<ByteDecompress 2> inValue : " << std::hex <<  inValue << std::endl;

            input_window.range(((i + 1) * c_parallelBit) - 1, i * c_parallelBit) = inValue;
        }

        // Initialize the loop readBytes variable to input_window buffer size as
        // that much data is already read from stream
        uint32_t readBytes = 2 * PARALLEL_BYTES;
        uint32_t processedBytes = 0;

        enum lz4DecompressStates stt_current_state = next_state;


    LZ4_decompressr2:
        for (; ((processedBytes + input_index) < input_size);) {
#pragma HLS PIPELINE II = 1
            uint8_t incrInputIdx = 0;
            outFlag = false;
            // ap_uint<8> token_value = input_window >> (input_index * 8);
            // token_lit_len = token_value.range(7, 4);
            // token_match_len = token_value.range(3, 0);

            // READ TOKEN stage
            stt_current_state = next_state;//mydebug
            if (next_state == READ_LITLEN_LIT_OFFSET) {
                // if works will be 1 cycle, or is 2 cycles : offset shift mv to next state
                ap_uint<8> token_value = input_window >> (input_index * 8);
                token_lit_len = token_value.range(7, 4);
                token_match_len = token_value.range(3, 0);
                token_match_len_p4 = token_match_len + 4;
                token_lit_len_p3 = token_lit_len + 3;

                bool c0 = (token_lit_len == 0xF);
                
                lit_len = token_lit_len;
                stt_lit_len = token_lit_len;
                stt_lit_len_all += token_lit_len;
                outStreamValue = input_window >> ((input_index+1) * 8);
                offset = input_window >> ((input_index+token_lit_len+1) * 8);

                if (c0) {
                    next_state = READ_LIT_LEN;
                    incrInputIdx = 1;
                    outFlag = false;
                } else if (lit_len == 0){
                    next_state = READ_OFFSET;
                    incrInputIdx = 1;
                    outFlag = false;
                } else if (lit_len<=0x4 && ((token_match_len !=0xF))) { //(token_match_len !=0xF)
                    next_state = READ_LITLEN_LIT_OFFSET;
                    incrInputIdx = token_lit_len_p3;
                    outFlag = true;

                    litlenStream << lit_len;
                    matchlenStream << token_match_len_p4;
                    offsetStream << offset;
#ifdef STT_M2
                    stt_write_tk++;
#endif
                } else { //if (lit_len>0x4) or (token_match_len ==0xF)    
                    next_state = READ_LITERAL;
                    incrInputIdx = 1;
                    outFlag = false;
                    litlenStream << lit_len;
                    matchlenStream << 0;
                    offsetStream << 0;
#ifdef STT_M2
                    stt_write_tk++;
#endif
                }
#ifdef STT_M2            
                stt_num_token++;
#endif
                
            } else if (next_state == READ_LIT_LEN) {//1
                ap_uint<8> token_value = input_window >> (input_index * 8);
                incrInputIdx = 1;
                lit_len += token_value;
                stt_lit_len += token_value;
                stt_lit_len_all += token_value;

                if (token_value == 0xFF) {
                    next_state = READ_LIT_LEN;
                } else {
                    next_state = READ_LITERAL;
                    litlenStream << lit_len;
                    matchlenStream << 0;
                    offsetStream << 0;
#ifdef STT_M2
                    stt_write_tk++;
#endif
                }
            } else if (next_state == READ_LITERAL) {//2
                outFlag = true;
                outStreamValue = input_window >> (input_index * 8);
                uint32_t localLitLen = lit_len;
                if (localLitLen <= PARALLEL_BYTES) {
                    incrInputIdx = lit_len;
                    lit_len = 0;
                    next_state = READ_OFFSET;
                } else {
                    incrInputIdx = PARALLEL_BYTES;
                    lit_len -= PARALLEL_BYTES;
                    next_state = READ_LITERAL;
                }
            } else if (next_state == READ_OFFSET) {//3
                offset = input_window >> (input_index * 8);
                bool c0 = (token_match_len == 0xF);
                incrInputIdx = 2;
                match_len = token_match_len + 4; //+4 because of LZ4 standard
                stt_match_len = token_match_len + 4;
                stt_match_len_all += stt_match_len;

                if (c0) {
                    next_state = READ_MATCH_LEN;
                } else {
                    next_state = READ_LITLEN_LIT_OFFSET;
                    litlenStream << 0;
                    matchlenStream << match_len;
                    offsetStream << offset;
#ifdef STT_M2
                    stt_write_tk++;
#endif
                }
            } else if (next_state == READ_MATCH_LEN) {//4
                ap_uint<8> token_value = input_window >> (input_index * 8);
                incrInputIdx = 1;
                match_len += token_value;
                stt_match_len += token_value;
                stt_match_len_all += token_value;

                if (token_value == 0xFF) {
                    next_state = READ_MATCH_LEN;
                } else {
                    next_state = READ_LITLEN_LIT_OFFSET;
                    litlenStream << 0;
                    matchlenStream << match_len;
                    offsetStream << offset;
#ifdef STT_M2
                    stt_write_tk++;
#endif
                }
            } else {
                assert(0);
            }
#ifndef __SYNTHESIS__
 //           stt_i_loop++;
#ifdef DEBUG
            stt_input_index += incrInputIdx;
            
            //if(stt_i_loop >3500 || (stt_i_loop<30)){
                printf("STT_M2 cnt_loop( %7d ) cnt_token( %7d ) state( %d )( %d ) index(%d)", stt_i_loop, stt_num_token, stt_current_state, next_state, stt_input_index);
                printf(" litlen(%2d )( %5d )( %5d )", token_lit_len, stt_lit_len, lit_len);
                printf(" matlen(%2d )( %5d )( %5d )", token_match_len, stt_match_len, token_match_len_p4);
                printf("\n");
                if(stt_input_index == 3810){
                    printf("\n");
                }
            //}
#endif
#endif

            input_index += incrInputIdx;
            bool inputIdxFlag = reg<bool>((input_index >= PARALLEL_BYTES));
            // write to input stream based on PARALLEL BYTES
            if (inputIdxFlag) {
                input_window >>= c_parallelBit;
                input_index -= PARALLEL_BYTES;
                processedBytes += PARALLEL_BYTES;

                if (readBytes < input_size) {
                    ap_uint<c_parallelBit> input;
#ifdef STT_M2
                stt_read_in++;
#endif
                    //bool nb = inStream.read_nb(input);
                    //if (nb) {
                    	inStream.read(input);
                        readBytes += PARALLEL_BYTES;
                        input_window.range(2 * c_parallelBit - 1, c_parallelBit) = input;
                    //}
                }
            }

            if (outFlag) {
                litStream << outStreamValue;
                outFlag = false;
#ifdef STT_M2
                stt_write_lit++;
#endif
            }

#ifdef STT_M2
            printf("STT_M2_OPT1 cnt_loop:\t%5d\t, cnt_token:\t%5d\t, state:\t%d\t, \t%d\t, ", stt_i_loop++, stt_num_token, stt_current_state, next_state);
            printf("litlen:\t%2d\t, \t%4d\t, \t%4d\t, ", token_lit_len, stt_lit_len, lit_len);
            printf("matlen:\t%2d\t, \t%4d\t, \t%4d\t, ", token_match_len, stt_match_len, match_len);
            printf("offset:\t%5d\t, ", offset);
            printf("R_in:\t%4d\t, ", stt_read_in);
            printf("W_lit:\t%4d\t, ", stt_write_lit);
            printf("incrIdx:\t%1d\t, ", incrInputIdx);
            printf("\n");
#endif

        }// end one block


    #ifndef __SYNTHESIS__
        printf("[Estmate] cnt_loop( %7d ) \n", stt_i_loop);
    #endif
    }//end block
#ifdef STT_M2
    printf("STT_M2_SUM_OPT1\t cnt_loop:\t%5d\t\n", stt_i_loop++);
    printf("STT_M2_SUM_OPT1\t cnt_tk_rd:\t%5d\t\n", stt_num_token);
    printf("STT_M2_SUM_OPT1\t cnt_tk_wr:\t%5d\t\n", stt_write_tk);//stt_lit_len_all
    printf("STT_M2_SUM_OPT1\t avg litLen:\t%5.2f\t\n", (float)stt_lit_len_all / (float)stt_num_token);
    printf("STT_M2_SUM_OPT1\t avg matLen:\t%5.2f\t\n", (float)stt_match_len_all / (float)stt_num_token);
    printf("STT_M2_SUM_OPT1\t tk per cycle:\t%5.2f\t\n", (float)stt_num_token / (float)stt_i_loop);
#endif

    if (!blockInfoStream.empty()) dt_lz4BlockInfo bInfo = blockInfoStream.read();

    // signalling end of transaction
    litlenStream << 0;
    matchlenStream << 0;
    offsetStream << 0;
    // printf("\nInIdx: %d \t outIdx: %d \t Input_size: %d \t read_from_stream: %d  \t written_to_stream: %d \t
    // output_count: %d\n",input_index, output_index,input_size,readBytes, out_written, output_count);
}

//______________________________________________________________________________
// added block mode
// <8, 65536>
// 64b inStream, 72b outStream

template <int PARALLEL_BYTES, int HISTORY_SIZE>
void lz4DecompressEngine_B
    (hls::stream<ap_uint<PARALLEL_BYTES * 8> >&                    inStream,
     hls::stream<ap_uint<(PARALLEL_BYTES * 8) + PARALLEL_BYTES> >& outStream,
     const uint32_t _input_size, bool *magicHeaderError, bool modeBlk) {

typedef ap_uint<PARALLEL_BYTES * 8> uintV_t; // 64b
typedef ap_uint<16> offset_dt;

uint32_t input_size1 = _input_size;

hls::stream<uint32_t>        litlenStream("litlenStream");
hls::stream<uintV_t>         litStream("litStream");
hls::stream<uintV_t>         headerStream("headerStream");
hls::stream<offset_dt>       offsetStream("offsetStream");
hls::stream<uint32_t>        matchlenStream("matchlenStream");
hls::stream<dt_lz4BlockInfo> blockInfoStream("blockInfoStream");
hls::stream<ap_uint<27> >    lzInfoStream("lzInfoStream");
const int scl_depth = 4;
#pragma HLS STREAM variable = litlenStream depth = 16 * scl_depth
#pragma HLS STREAM variable = headerStream depth = 16 * scl_depth
#pragma HLS STREAM variable = litStream depth = 256 * scl_depth
#pragma HLS STREAM variable = offsetStream depth = 16 * scl_depth
#pragma HLS STREAM variable = matchlenStream depth = 16 * scl_depth
#pragma HLS STREAM variable = blockInfoStream depth = 4 * scl_depth
#pragma HLS STREAM variable = lzInfoStream depth = 4 * scl_depth

#pragma HLS BIND_STORAGE variable = litlenStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = litStream    type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = headerStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = offsetStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = matchlenStream  type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = blockInfoStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = lzInfoStream    type = FIFO impl = SRL

#pragma HLS dataflow

//lz4HeaderProcessing_B<PARALLEL_BYTES>
    //(inStream, headerStream, blockInfoStream, input_size1, magicHeaderError, modeBlk);

lz4HeaderProcessing_C<PARALLEL_BYTES>
    (inStream, headerStream, blockInfoStream, input_size1, magicHeaderError, modeBlk);

hls::stream<uintV_t>         headerStream1("headerStream1");
hls::stream<uintV_t>         headerStream2("headerStream2");
hls::stream<dt_lz4BlockInfo> blockInfoStream1("blockInfoStream1");
hls::stream<dt_lz4BlockInfo> blockInfoStream2("blockInfoStream2");
#pragma HLS STREAM variable = headerStream1 depth = 16 * scl_depth
#pragma HLS STREAM variable = headerStream2 depth = 16 * scl_depth
#pragma HLS STREAM variable = blockInfoStream1 depth = 4 * scl_depth
#pragma HLS STREAM variable = blockInfoStream2 depth = 4 * scl_depth


lz4MultiByteDecompress_opt1<PARALLEL_BYTES, uint32_t>
    (headerStream, litlenStream, litStream, offsetStream, matchlenStream, blockInfoStream);
    

//std::cout << "================ lz4MultiByteDecompress " << std::endl;

//L1_inc/hw/inflate.hpp
details::lzPreProcessingUnitLL<uint32_t, PARALLEL_BYTES>
    (litlenStream, matchlenStream, offsetStream, lzInfoStream);

//std::cout << "================ lzPreProcessingUnitLL " << std::endl;

//L1_inc/hw/lz_decompress.hpp
lzMultiByteDecompressLL<PARALLEL_BYTES, HISTORY_SIZE, 16, ap_uint<17> >
    (litStream, lzInfoStream, outStream);

//std::cout << "================ lzMultiByteDecompress " << std::endl;

}

//______________________________________________________________________________
// added block mode
// <8, 65536>
// 64b inStream, 72b outStream

template <int PARALLEL_BYTES, int PARALLEL_OUT_BYTES, int HISTORY_SIZE>
void lz4DecompressEngine_opt3
    (hls::stream<ap_uint<PARALLEL_BYTES * 8> >&                    inStream,
     hls::stream<ap_uint<(PARALLEL_OUT_BYTES * 8) + PARALLEL_OUT_BYTES> >& outStream, // opt2
     const uint32_t _input_size, bool *magicHeaderError, bool modeBlk) {

typedef ap_uint<PARALLEL_BYTES * 8> uintV_t; // 64b
typedef ap_uint<16> offset_dt;

uint32_t input_size1 = _input_size;

hls::stream<uint32_t>        litlenStream("litlenStream");
hls::stream<uintV_t>         litStream("litStream");
hls::stream<uintV_t>         headerStream("headerStream");
hls::stream<uintV_t>         headerStream1("headerStream1");
hls::stream<uintV_t>         headerStream2("headerStream2");
hls::stream<offset_dt>       offsetStream("offsetStream");
hls::stream<uint32_t>        matchlenStream("matchlenStream");
hls::stream<dt_lz4BlockInfo> blockInfoStream("blockInfoStream");
hls::stream<dt_lz4BlockInfo> blockInfoStream1("blockInfoStream1");
hls::stream<dt_lz4BlockInfo> blockInfoStream2("blockInfoStream2");
hls::stream<ap_uint<27+1+5> >    lzInfoStream("lzInfoStream");// // opt3

#pragma HLS STREAM variable = litlenStream depth = 16
#pragma HLS STREAM variable = headerStream depth = 16
#pragma HLS STREAM variable = headerStream1 depth = 16
#pragma HLS STREAM variable = headerStream2 depth = 16

#pragma HLS STREAM variable = litStream depth = 256
#pragma HLS STREAM variable = offsetStream depth = 16
#pragma HLS STREAM variable = matchlenStream depth = 16
#pragma HLS STREAM variable = blockInfoStream depth = 4
#pragma HLS STREAM variable = blockInfoStream1 depth = 4
#pragma HLS STREAM variable = blockInfoStream2 depth = 4

#pragma HLS STREAM variable = lzInfoStream depth = 4

#pragma HLS BIND_STORAGE variable = litlenStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = litStream    type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = headerStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = offsetStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = matchlenStream  type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = blockInfoStream type = FIFO impl = SRL
#pragma HLS BIND_STORAGE variable = lzInfoStream    type = FIFO impl = SRL

#pragma HLS dataflow

//lz4HeaderProcessing_B<PARALLEL_BYTES>
    //(inStream, headerStream, blockInfoStream, input_size1, magicHeaderError, modeBlk);

lz4HeaderProcessing_C<PARALLEL_BYTES>
    (inStream, headerStream, blockInfoStream, input_size1, magicHeaderError, modeBlk);

lz4MultiByteDecompress_opt1<PARALLEL_BYTES, uint32_t>
    (headerStream, litlenStream, litStream, offsetStream, matchlenStream, blockInfoStream);

//std::cout << "================ lz4MultiByteDecompress " << std::endl;

//L1_inc/hw/inflate.hpp
// details::lzPreProcessingUnitLL<uint32_t, PARALLEL_BYTES>
//     (litlenStream, matchlenStream, offsetStream, lzInfoStream);
details::lzPreProcessingUnitLL_opt3<uint32_t, PARALLEL_BYTES, PARALLEL_OUT_BYTES>// opt3
    (litlenStream, matchlenStream, offsetStream, lzInfoStream);

//std::cout << "================ lzPreProcessingUnitLL " << std::endl;

//L1_inc/hw/lz_decompress.hpp
lzMultiByteDecompressLL_opt3<PARALLEL_BYTES, PARALLEL_OUT_BYTES, HISTORY_SIZE, 16, ap_uint<17> >// opt3
    (litStream, lzInfoStream, outStream);

//std::cout << "================ lzMultiByteDecompress " << std::endl;

}



} // namespace compression
} // namespace xf

#endif // _XFCOMPRESSION_LZ4_DECOMPRESS_HPP_
