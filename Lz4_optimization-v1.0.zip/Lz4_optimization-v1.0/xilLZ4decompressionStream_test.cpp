/*
 * (c) Copyright 2019 Xilinx, Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

//
//
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------


//#include "lz4_multibyte_decompress_stream.hpp"

#include "hls_stream.h"
#include <ap_int.h>
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string>
#include "ap_axi_sdata.h"

#include "xilLZ4decompressionStream_test.h"

#define MULTIPLE_BYTES 8
// #define OUTPUT_BYTES MULTIPLE_BYTES
//#define OUTPUT_BYTES 16
typedef unsigned int uint;
typedef ap_axiu<MULTIPLE_BYTES * 8, 0, 0, 0> uintV_t;
typedef ap_axiu<OUTPUT_BYTES * 8, 0, 0, 0> uintVout_t;
typedef ap_axiu<32, 0, 0, 0>                 uint32s_t;

////////////////////////////////////////////////////////////////////////////////////////

int main(int argc, char* argv[]) {

	hls::stream<ap_axiu<MULTIPLE_BYTES * 8, 0, 0, 0> > inaxistream;
	hls::stream<ap_axiu<OUTPUT_BYTES * 8, 0, 0, 0> > outaxistream;
	hls::stream<ap_axiu<32, 0, 0, 0> > outaxistreamsize;
    uint32_t input_size;

    std::fstream compressedFile;
    compressedFile.open(argv[1], std::fstream::binary | std::fstream::in);
    if (!compressedFile.is_open()) {
        std::cout << "<INFO> Cannot open the compressed file!!" << std::endl;
        exit(0);
    }
    compressedFile.seekg(0, std::ios::end); // reaching to end of file
    uint32_t comp_length = (uint32_t)compressedFile.tellg();
    compressedFile.seekg(0, std::ios::beg);

// needed for data with 8B at the end
// comp_length=522806;

    std::cout << "<INFO> length of comprssed file (byte?): " << comp_length << std::endl;

    uintV_t x;
    ap_uint<MULTIPLE_BYTES * 8> temp_in;
    uint32_t i;

    int noflines = 10;

    for (i = 0; i < comp_length; i += MULTIPLE_BYTES) {
        compressedFile.read((char*)&temp_in, MULTIPLE_BYTES);
        x.data = temp_in;
        x.last = (i > (comp_length - (MULTIPLE_BYTES-1))) ? 1 : 0; //
        if (x.last == 1) {std::cout << "LAST" << std::endl;}
        inaxistream << x;
        if (--noflines>0) 
            std::cout << "<INFO> inaxistream i: " << std::dec << i << "  " << std::hex << temp_in << std::endl;
    }

    ///////////////////////////////////////////////////////////////////////////////

    bool magicHeaderError; // CMS 03/28/23

bool modeBlk = false;
if (argc > 4)
    modeBlk = true;

    // Decompression call
    xilLz4DecompressStream_B
        (inaxistream, outaxistream, outaxistreamsize, comp_length, &magicHeaderError, modeBlk); 

    ///////////////////////////////////////////////////////////////////////////////

    std::ofstream outFile;
    outFile.open(argv[2], std::fstream::binary | std::fstream::out);

    std::ifstream originalFile;
    originalFile.open(argv[3], std::ofstream::binary | std::ofstream::in);
    if (!originalFile.is_open()) {
        std::cout << "<INFO> Cannot open the original file!!" << std::endl;
        exit(0);
    }

    uintVout_t val;
    const uint size = (OUTPUT_BYTES * 8);
    ap_uint<OUTPUT_BYTES * 8> temp_out;
    ap_uint<OUTPUT_BYTES * 8> g;
    ap_uint<OUTPUT_BYTES * 8> o;

    // retrieve output length from DUT
    uint32s_t   out_length_stream;
    ap_uint<32> out_length;
    out_length_stream = outaxistreamsize.read();
    out_length        = out_length_stream.data;
    std::cout << "<INFO> outaxistreamsize (in bytes) : " << std::dec << out_length << std::endl;

    uint bytes_remaining = out_length;
    uint output_bytes_i  = OUTPUT_BYTES;

    bool pass       = true;
    bool output_eof = false;

    noflines = 10;
    int testlines = 48038;
    int cntline = 0;
    int cmpsize = 0;

    while (output_eof==0) {
        val        = outaxistream.read();
        output_eof = val.last;
        temp_out   = val.data;

        if (bytes_remaining > OUTPUT_BYTES-1)
		   output_bytes_i = OUTPUT_BYTES;
        else
           output_bytes_i = bytes_remaining;

        outFile.write((char*)&temp_out, output_bytes_i);
        bytes_remaining = bytes_remaining - output_bytes_i;
        if (--noflines>0) 
        // cntline++;
        // if(cntline > testlines)
        std::cout << "<INFO> outaxistream: " << std::hex << temp_out << "  bytes_remaining " <<
      	  std::dec << bytes_remaining << "  tlast " << output_eof << std::endl;

        // Compare with original (raw) file
#if(1)
        g = 0;
        o = temp_out;
        originalFile.read((char*)&g, OUTPUT_BYTES);
        cmpsize = (bytes_remaining >= OUTPUT_BYTES )? (size) : (bytes_remaining*8);
          if (o != g) {
            for (uint8_t v = 0; v < cmpsize; v++) {
                uint8_t e = g.range((v + 1) * OUTPUT_BYTES - 1, v * OUTPUT_BYTES);
                uint8_t r = o.range((v + 1) * OUTPUT_BYTES - 1, v * OUTPUT_BYTES);
                if (e != r) {
                    pass = false;
                    std::cout << "<INFO> Expected=" << std::hex << e << " got=" << r << std::endl;
                    std::cout << "<INFO> -----TEST FAILED: The input file and the file after "
                              << "<INFO> decompression are not similar!-----" << std::endl;
                    exit(0);
                }
            }
          }
 #endif

    } // end while

    outFile.close();
    if (pass) {
        std::cout << "<INFO> TEST PASSED" << std::endl;
    } else {
        std::cout << "<INFO> TEST FAILED" << std::endl;
    }
    originalFile.close();
    compressedFile.close();
}
