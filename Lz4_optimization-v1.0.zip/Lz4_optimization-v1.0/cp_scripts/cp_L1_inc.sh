#!/bin/bash

export SRC_PATH="../../../Vitis_Libraries/data_compression/L1/include/hw"
export DEST_PATH="../src/L1_inc/hw" 

for githubfile in axi_stream_utils.hpp lz4_compress.hpp mm2s.hpp zlib_tables.hpp block_packer.hpp s2mm.hpp zstd_compress.hpp checksum_wrapper.hpp snappy_compress.hpp zstd_compress_internal.hpp compress_utils.hpp snappy_decompress_details.hpp zstd_compress_multicore.hpp fixed_codes.hpp lz4_packer.hpp snappy_decompress.hpp zstd_decompress.hpp huffman_decoder.hpp lz4_specs.hpp stream_downsizer.hpp zstd_encoders.hpp huffman_encoder.hpp lz_compress.hpp stream_upsizer.hpp zstd_fse_decoder.hpp huffman_treegen.hpp zlib_compress_details.hpp zstd_specs.hpp lz_optional.hpp zlib_compress.hpp lzx_decompress.hpp zlib_specs.hpp
do
  cp $SRC_PATH/$githubfile $DEST_PATH/$githubfile
  echo "copying $SRC_PATH/$githubfile $DEST_PATH/$githubfile"
done



