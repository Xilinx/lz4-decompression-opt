#!/bin/bash

export SRC_PATH="../../../Vitis_Libraries/data_compression/L2/src"
export DEST_PATH="../src/L2_src" 

cp $SRC_PATH/* $DEST_PATH
echo "copying $SRC_PATH/* $DEST_PATH"



