#!/bin/bash

export SRC_PATH="../../../Vitis_Libraries/data_compression/L2/tests/lz4_dec_streaming_parallelByte8"
export DEST_PATH=".." 

cp $SRC_PATH/sample.txt $DEST_PATH
echo "copying $SRC_PATH/* $DEST_PATH"

lz4 $DEST_PATH/sample.txt
echo "compressing $DEST_PATH/sample.txt"

mv $DEST_PATH/sample.txt.lz4 $DEST_PATH/sample.lz4
echo "renaming $DEST_PATH/sample.txt.lz4 to sample.lz4"


