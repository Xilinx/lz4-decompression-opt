#!/bin/bash

export SRC_PATH="../../..//Vitis_Libraries/data_compression/L2/include"
export DEST_PATH="../src/L2_inc" 

for githubfile in adler32_mm.hpp lz4_multibyte_decompress_mm.hpp zlib_decompress_dynamic.hpp checksum_mm.hpp zlib_decompress_fixed.hpp crc32_mm.hpp lz4_p2p.hpp zlib_decompress.hpp gzip_compress_fixed_stream.hpp lz4_packer_mm.hpp zlib_decompress_quadcore_8kb.hpp gzip_compress_multicore_mm.hpp snappy_compress_mm.hpp zlib_huffman_enc_mm.hpp gzip_compress_multicore_stream.hpp  snappy_compress_stream.hpp zlib_lz77_compress_mm.hpp gzip_compress_stream.hpp snappy_multibyte_decompress_mm.hpp zlib_treegen_mm.hpp gzip_decompress_mm.hpp snappy_multibyte_decompress_stream.hpp zstd_compress_multicore_stream.hpp gzip_decompress_multicore.hpp snappy_multicore_decompress_stream.hpp zstd_compress_stream.hpp lz4_compress_mm.hpp zlib_compress_multi_engine_mm.hpp zstd_decompress_stream.hpp lz4_compress_stream.hpp zlib_decompress_8kb_checksum.hpp

do
  cp $SRC_PATH/$githubfile $DEST_PATH/$githubfile
  echo "copying $SRC_PATH/$githubfile $DEST_PATH/$githubfile"
done



