#!/bin/bash

export SRC_PATH="../../../Vitis_Libraries/security/L1/include"
export DEST_PATH="../src/security_L1_inc" 

cp $SRC_PATH/xf_security_L1.hpp $DEST_PATH
echo "copying $SRC_PATH/xf_security_L1.hpp $DEST_PATH"

cp -r $SRC_PATH/xf_security $DEST_PATH
echo "copying $SRC_PATH/xf_security_L1.hpp $DEST_PATH"
